from fastapi import FastAPI
from fastapi.responses import JSONResponse
import time

app = FastAPI()

# 缓存机制，减少抓取次数
api_cache = {"data": [], "last_update": 0}
CACHE_DURATION = 6*60*60  # 6小时

@app.get("/")
def get_api_list():
    now = time.time()
    if now - api_cache["last_update"] < CACHE_DURATION:
        return JSONResponse(api_cache["data"])

    # 自动生成可用 API 列表
    apis = [
        {"name":"天天基金手机版","url":"https://fundmobapi.eastmoney.com/FundMApi/FundNetValueEstimate?fc={code}&deviceid=app&version=1.0"},
        {"name":"Yahoo Finance","url":"https://query1.finance.yahoo.com/v7/finance/quote?symbols={code}"},
        {"name":"新浪财经快照","url":"https://hq.sinajs.cn/list=sh{code}"}
    ]

    api_cache["data"] = apis
    api_cache["last_update"] = now
    return JSONResponse(apis)
